// Testing 
class Results
{

public String OutResults(int marks){
// Checking
	if (marks>70 && marks>65)
		return "A Pass";
	else if (marks>49|| marks>50)
		return "B Pass";
	else if (marks>45)
		return "C Pass";
	else
		return "Fail";
}


}