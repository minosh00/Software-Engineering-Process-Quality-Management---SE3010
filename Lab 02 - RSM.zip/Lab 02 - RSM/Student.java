class Student
{
String name,address;
int age;

Student()
{
name="";
age=0;
address="";
}

void setName(String nName)
{
	name=nName;
}

void setAddress(String nAddr)
{
	address=nAddr;
}

void setAge(int nAge)
{
	age=nAge;
}


String getName()
{
	return name;
}

String getAddress()
{
	return address;
}


int getAge()
{
	return age;
}



void displayInfo()
{
	System.out.println("the name is :"+getName());
	System.out.println("the age is :"+getAge());
	System.out.println("the address is :"+getAddress());
}


public static void main(String args[])
{

	Student student1=new Student();
	student1.setName("Saman");
	student1.setAddress("Malabe");
	student1.setAge(23);

	student1.displayInfo();

}


}


