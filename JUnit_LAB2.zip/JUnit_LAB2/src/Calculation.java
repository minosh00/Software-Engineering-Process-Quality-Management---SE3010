
public class Calculation {
	public int addition(int a,int b)
	{
		int total=a+b;
		return total;
	}
	public int subtraction(int a,int b)
	{
		int total=a-b;
		return total;
	}

}
