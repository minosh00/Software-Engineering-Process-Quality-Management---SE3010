import static org.junit.Assert.*;

import org.junit.Test;

import junit.framework.Assert;

public class CalculationTest {
	Calculation calculation = new Calculation();

	


	@Test
	public void testAddition() {
		int result = calculation.addition(2,5);
		int expectedtotal=7;
	
		assertEquals(result,expectedtotal);
	}

	@Test
	public void testSubtraction() {
		//fail("Not yet implemented");
		int result = calculation.subtraction(20,15);
		int expectedtotal=5;
		assertEquals(result,expectedtotal);
	}

}
